 <?php
session_start();

if (isset($_POST['logOutSub'])) {
    $_SESSION['login_user']="logout";
	
        }
        ?>

